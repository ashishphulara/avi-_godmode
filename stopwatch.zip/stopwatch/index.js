
let hr =0;

let min = 0;

let sec = 0;

let count =0;

let timer = false;

let startButton  = document.getElementById("start")
let stopButton  = document.getElementById("stop")
let resetButton  = document.getElementById("reset")

stopButton.disabled=true;
resetButton.disabled=true;

function  start(){
    if(!timer){

        timer = true;
        startButton.disabled=true;
        stopButton.disabled=false;
    resetButton.disabled=false;
        stopwatch();
    }
}

 function stop(){
//     if(timer == true) {
//         hr = document.getElementById("hr").innerHTML;
//         min = document.getElementById("min").innerHTML;
//         sec = document.getElementById("sec").innerHTML;

//         startButton.disabled = false;
//     startButton.disabled = true;

//     timer = false;
//     stopButton.innerHTML = "continue";
//   }
//   else{
//     timer = true;
//     stopwatch();
//     document.getElementById("stop").innerHTML = "Pause";

//   }
  
    timer = false
        document.getElementById("stop").innerHTML="continue"
        
        }
         stopwatch();
         
       
         



function reset(){
    timer = false;
    hr=00;
    min=00;
    sec=00;
    count=00;
    document.getElementById("sec").innerHTML = "00";
    document.getElementById("min").innerHTML = "00";
   document.getElementById("hrs").innerHTML ="00";
   startButton.disabled =false
   stopButton.disabled=true;
resetButton.disabled=true;
document.getElementById("stop").innerHTML = "pause"
     
}

 function stopwatch(){
    if(timer==true){
        count = count+1;

        if(count == 100){
            sec=sec+1;
            count =00;
        }
        if(sec == 60){
            min = min+1;
            sec = 00;
        }
        if(min == 60){
            hr = hr+1;
            min = 00;
            sec = 00;
        }
        let hrString=hr
        let minString=min;
        let secString=sec;
        if(hr<10){
            hrString="0" + hrString;
        }
        if(min<10){
            minString="0" + minString;
        }
        if(sec<10){
            secString="0" + secString;
        }
    //   document.getElementById("count").innerHTML= count;
        document.getElementById("sec").innerHTML = secString;
    document.getElementById("min").innerHTML = minString
   document.getElementById("hrs").innerHTML =hrString

        setTimeout("stopwatch()",10);
    }

}